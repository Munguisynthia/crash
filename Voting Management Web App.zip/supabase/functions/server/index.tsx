import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

app.use('*', logger(console.log));
app.use("/*", cors({
  origin: "*",
  allowHeaders: ["Content-Type", "Authorization"],
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  exposeHeaders: ["Content-Length"],
  maxAge: 600,
}));

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") || "";
const BASE_URL = "https://rafngqdvmlegmoxhoanz.supabase.co/functions/v1/make-server-1c5486f2";
const APP_URL = "https://figma.com"; // frontend URL placeholder — emails will link to the app

// ─── Helpers ────────────────────────────────────────────────────────────────

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + "vt_salt_2024");
  const hash = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function generateToken(): string {
  return crypto.randomUUID().replace(/-/g, "") + crypto.randomUUID().replace(/-/g, "");
}

async function sendEmail(to: string, subject: string, html: string): Promise<boolean> {
  if (!RESEND_API_KEY) {
    console.log("RESEND_API_KEY not set — email skipped:", { to, subject });
    return false;
  }
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "VoteTrack <noreply@votetrack.app>",
        to,
        subject,
        html,
      }),
    });
    if (!res.ok) {
      const err = await res.text();
      console.log("Resend error:", err);
      return false;
    }
    return true;
  } catch (e) {
    console.log("Resend fetch error:", e);
    return false;
  }
}

async function getAuthSession(authHeader: string | null): Promise<{ userId: string; role: string; schoolId?: string } | null> {
  if (!authHeader || !authHeader.startsWith("Bearer ")) return null;
  const token = authHeader.split(" ")[1];
  const session = await kv.get(`auth:${token}`);
  if (!session) return null;
  const s = session as any;
  if (s.expires < Date.now()) {
    await kv.del(`auth:${token}`);
    return null;
  }
  return s;
}

// ─── Health ──────────────────────────────────────────────────────────────────

app.get("/make-server-1c5486f2/health", (c) => c.json({ status: "ok" }));

// ─── System Admin Setup ──────────────────────────────────────────────────────

// POST /sysadmin/setup — creates the system admin account (first-time only)
app.post("/make-server-1c5486f2/sysadmin/setup", async (c) => {
  try {
    const { email, password } = await c.req.json();
    if (!email || !password) return c.json({ error: "Email and password required" }, 400);
    const existing = await kv.get("sysadmin");
    if (existing) return c.json({ error: "System admin already exists" }, 409);
    const passwordHash = await hashPassword(password);
    await kv.set("sysadmin", { email, passwordHash, createdAt: Date.now() });
    return c.json({ success: true, message: "System admin created" });
  } catch (e) {
    console.log("sysadmin/setup error:", e);
    return c.json({ error: "Setup failed" }, 500);
  }
});

// POST /sysadmin/login
app.post("/make-server-1c5486f2/sysadmin/login", async (c) => {
  try {
    const { email, password } = await c.req.json();
    const admin = await kv.get("sysadmin") as any;
    if (!admin) return c.json({ error: "System admin not configured" }, 404);
    const hash = await hashPassword(password);
    if (admin.email !== email || admin.passwordHash !== hash) {
      return c.json({ error: "Invalid credentials" }, 401);
    }
    const token = generateToken();
    await kv.set(`auth:${token}`, {
      userId: "sysadmin",
      role: "sysadmin",
      expires: Date.now() + 8 * 60 * 60 * 1000,
    });
    return c.json({ token, role: "sysadmin" });
  } catch (e) {
    console.log("sysadmin/login error:", e);
    return c.json({ error: "Login failed" }, 500);
  }
});

// GET /sysadmin/check — check if system admin exists
app.get("/make-server-1c5486f2/sysadmin/check", async (c) => {
  const admin = await kv.get("sysadmin");
  return c.json({ exists: !!admin });
});

// ─── Schools (System Admin) ───────────────────────────────────────────────────

// GET /sysadmin/schools
app.get("/make-server-1c5486f2/sysadmin/schools", async (c) => {
  const session = await getAuthSession(c.req.header("Authorization"));
  if (!session || session.role !== "sysadmin") return c.json({ error: "Unauthorized" }, 401);
  const schoolIds = (await kv.get("schools") as string[]) || [];
  const schools = await kv.mget(schoolIds.map(id => `school:${id}`));
  return c.json({ schools: schools.filter(Boolean) });
});

// POST /sysadmin/schools — register a new school
app.post("/make-server-1c5486f2/sysadmin/schools", async (c) => {
  const session = await getAuthSession(c.req.header("Authorization"));
  if (!session || session.role !== "sysadmin") return c.json({ error: "Unauthorized" }, 401);
  try {
    const { name, govId, email, studentPrefix } = await c.req.json();
    if (!name || !govId || !email || !studentPrefix) return c.json({ error: "All fields required" }, 400);
    if (studentPrefix.length !== 4) return c.json({ error: "Student prefix must be exactly 4 characters" }, 400);

    const id = crypto.randomUUID();
    const verifyToken = generateToken();
    const school = { id, name, govId, email, studentPrefix: studentPrefix.toUpperCase(), verified: false, createdAt: Date.now() };
    await kv.set(`school:${id}`, school);
    await kv.set(`token:${verifyToken}`, { type: "school_access", schoolId: id, expires: Date.now() + 7 * 24 * 60 * 60 * 1000 });

    const schoolIds = (await kv.get("schools") as string[]) || [];
    schoolIds.push(id);
    await kv.set("schools", schoolIds);

    // Also index by prefix
    await kv.set(`school_prefix:${studentPrefix.toUpperCase()}`, id);

    const verifyUrl = `${APP_URL}/verify/school/${verifyToken}`;
    await sendEmail(email, `Welcome to VoteTrack — ${name}`, `
      <div style="font-family: Inter, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        <h1 style="color: #1e3a5f; font-size: 28px; margin-bottom: 8px;">Welcome to VoteTrack</h1>
        <p style="color: #5a6a80; font-size: 16px; margin-bottom: 24px;">Your school <strong>${name}</strong> has been registered on VoteTrack.</p>
        <p style="color: #0f1923; font-size: 16px; margin-bottom: 24px;">Click the button below to set up your school administration account:</p>
        <a href="${verifyUrl}" style="display: inline-block; background: #1e3a5f; color: #ffffff; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 16px;">Access School Portal</a>
        <p style="color: #5a6a80; font-size: 13px; margin-top: 32px;">This link expires in 7 days. If you didn't expect this email, please ignore it.</p>
      </div>
    `);

    return c.json({ success: true, school });
  } catch (e) {
    console.log("sysadmin/schools POST error:", e);
    return c.json({ error: "Failed to register school" }, 500);
  }
});

// ─── School Access Verification ───────────────────────────────────────────────

// GET /verify/school/:token
app.get("/make-server-1c5486f2/verify/school/:token", async (c) => {
  const token = c.req.param("token");
  const tokenData = await kv.get(`token:${token}`) as any;
  if (!tokenData || tokenData.type !== "school_access" || tokenData.expires < Date.now()) {
    return c.json({ error: "Invalid or expired token" }, 400);
  }
  const school = await kv.get(`school:${tokenData.schoolId}`) as any;
  if (!school) return c.json({ error: "School not found" }, 404);
  return c.json({ valid: true, school: { id: school.id, name: school.name, email: school.email }, token });
});

// POST /verify/school/:token — school sets up admin account
app.post("/make-server-1c5486f2/verify/school/:token", async (c) => {
  const token = c.req.param("token");
  const tokenData = await kv.get(`token:${token}`) as any;
  if (!tokenData || tokenData.type !== "school_access" || tokenData.expires < Date.now()) {
    return c.json({ error: "Invalid or expired token" }, 400);
  }
  try {
    const { adminName, password } = await c.req.json();
    if (!adminName || !password) return c.json({ error: "Name and password required" }, 400);
    const school = await kv.get(`school:${tokenData.schoolId}`) as any;
    if (!school) return c.json({ error: "School not found" }, 404);

    const adminId = crypto.randomUUID();
    const passwordHash = await hashPassword(password);
    const admin = {
      id: adminId,
      schoolId: school.id,
      email: school.email,
      name: adminName,
      passwordHash,
      createdAt: Date.now(),
    };
    await kv.set(`admin:${adminId}`, admin);
    await kv.set(`admin_email:${school.email}`, adminId);
    school.verified = true;
    await kv.set(`school:${school.id}`, school);
    await kv.del(`token:${token}`);

    return c.json({ success: true, message: "School admin account created" });
  } catch (e) {
    console.log("verify/school POST error:", e);
    return c.json({ error: "Setup failed" }, 500);
  }
});

// ─── School Admin Auth ────────────────────────────────────────────────────────

// POST /school-admin/login
app.post("/make-server-1c5486f2/school-admin/login", async (c) => {
  try {
    const { email, password } = await c.req.json();
    if (!email || !password) return c.json({ error: "Email and password required" }, 400);
    const adminId = await kv.get(`admin_email:${email}`) as string;
    if (!adminId) return c.json({ error: "Invalid credentials" }, 401);
    const admin = await kv.get(`admin:${adminId}`) as any;
    if (!admin) return c.json({ error: "Admin account not found" }, 401);
    const hash = await hashPassword(password);
    if (admin.passwordHash !== hash) return c.json({ error: "Invalid credentials" }, 401);
    const token = generateToken();
    await kv.set(`auth:${token}`, {
      userId: adminId,
      role: "school_admin",
      schoolId: admin.schoolId,
      expires: Date.now() + 8 * 60 * 60 * 1000,
    });
    const school = await kv.get(`school:${admin.schoolId}`) as any;
    return c.json({ token, role: "school_admin", admin: { id: adminId, name: admin.name, email: admin.email }, school });
  } catch (e) {
    console.log("school-admin/login error:", e);
    return c.json({ error: "Login failed" }, 500);
  }
});

// ─── Students (School Admin manages) ─────────────────────────────────────────

// POST /school-admin/students
app.post("/make-server-1c5486f2/school-admin/students", async (c) => {
  const session = await getAuthSession(c.req.header("Authorization"));
  if (!session || session.role !== "school_admin") return c.json({ error: "Unauthorized" }, 401);
  try {
    const { name, email, studentId } = await c.req.json();
    if (!name || !email || !studentId) return c.json({ error: "Name, email, and student ID required" }, 400);
    const school = await kv.get(`school:${session.schoolId}`) as any;
    if (!school) return c.json({ error: "School not found" }, 404);
    const prefix = studentId.toUpperCase().substring(0, 4);
    if (prefix !== school.studentPrefix) {
      return c.json({ error: `Student ID must start with ${school.studentPrefix}` }, 400);
    }

    const existing = await kv.get(`student_id:${studentId.toUpperCase()}`);
    if (existing) return c.json({ error: "Student ID already registered" }, 409);

    const id = crypto.randomUUID();
    const verifyToken = generateToken();
    const student = { id, name, email, studentId: studentId.toUpperCase(), schoolId: session.schoolId, schoolPrefix: prefix, verified: false, createdAt: Date.now() };
    await kv.set(`student:${id}`, student);
    await kv.set(`student_id:${studentId.toUpperCase()}`, id);
    await kv.set(`student_email:${email}:${studentId.toUpperCase()}`, id);
    await kv.set(`token:${verifyToken}`, { type: "student_verify", studentId: id, expires: Date.now() + 7 * 24 * 60 * 60 * 1000 });

    const studentIds = (await kv.get(`school:${session.schoolId}:students`) as string[]) || [];
    studentIds.push(id);
    await kv.set(`school:${session.schoolId}:students`, studentIds);

    const verifyUrl = `${APP_URL}/verify/student/${verifyToken}`;
    await sendEmail(email, `You've been registered on VoteTrack — ${school.name}`, `
      <div style="font-family: Inter, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        <h1 style="color: #1e3a5f; font-size: 28px; margin-bottom: 8px;">Welcome to VoteTrack</h1>
        <p style="color: #5a6a80; font-size: 16px; margin-bottom: 8px;">Hi <strong>${name}</strong>,</p>
        <p style="color: #0f1923; font-size: 16px; margin-bottom: 24px;">You've been registered as a student voter at <strong>${school.name}</strong>. Click below to verify your account:</p>
        <a href="${verifyUrl}" style="display: inline-block; background: #1e3a5f; color: #ffffff; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 16px;">Verify My Account</a>
        <p style="color: #5a6a80; font-size: 14px; margin-top: 24px;">Your Student ID: <strong>${studentId.toUpperCase()}</strong></p>
        <p style="color: #5a6a80; font-size: 13px; margin-top: 16px;">This link expires in 7 days.</p>
      </div>
    `);

    return c.json({ success: true, student: { ...student, passwordHash: undefined } });
  } catch (e) {
    console.log("school-admin/students POST error:", e);
    return c.json({ error: "Failed to register student" }, 500);
  }
});

// GET /school-admin/students
app.get("/make-server-1c5486f2/school-admin/students", async (c) => {
  const session = await getAuthSession(c.req.header("Authorization"));
  if (!session || session.role !== "school_admin") return c.json({ error: "Unauthorized" }, 401);
  const studentIds = (await kv.get(`school:${session.schoolId}:students`) as string[]) || [];
  const students = (await kv.mget(studentIds.map(id => `student:${id}`))).filter(Boolean).map((s: any) => ({ ...s, passwordHash: undefined }));
  return c.json({ students });
});

// GET /verify/student/:token
app.get("/make-server-1c5486f2/verify/student/:token", async (c) => {
  const token = c.req.param("token");
  const tokenData = await kv.get(`token:${token}`) as any;
  if (!tokenData || tokenData.type !== "student_verify" || tokenData.expires < Date.now()) {
    return c.json({ error: "Invalid or expired link" }, 400);
  }
  const student = await kv.get(`student:${tokenData.studentId}`) as any;
  if (!student) return c.json({ error: "Student not found" }, 404);
  student.verified = true;
  await kv.set(`student:${student.id}`, student);
  await kv.del(`token:${token}`);
  return c.json({ success: true, message: "Account verified successfully", studentId: student.studentId });
});

// ─── Student Auth (OTP flow) ──────────────────────────────────────────────────

// POST /auth/request-otp
app.post("/make-server-1c5486f2/auth/request-otp", async (c) => {
  try {
    const { email, studentId } = await c.req.json();
    if (!email || !studentId) return c.json({ error: "Email and student ID required" }, 400);

    const lookupId = await kv.get(`student_email:${email}:${studentId.toUpperCase()}`) as string;
    if (!lookupId) return c.json({ error: "No student found with that email and student ID combination" }, 404);

    const student = await kv.get(`student:${lookupId}`) as any;
    if (!student) return c.json({ error: "Student record not found" }, 404);
    if (!student.verified) return c.json({ error: "Please verify your account first using the link sent to your email" }, 403);

    const otp = generateOTP();
    const expires = Date.now() + 10 * 60 * 1000;
    await kv.set(`otp:${email}:${studentId.toUpperCase()}`, { code: otp, expires, studentId: lookupId });

    await sendEmail(email, "Your VoteTrack Login Code", `
      <div style="font-family: Inter, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        <h1 style="color: #1e3a5f; font-size: 28px; margin-bottom: 8px;">Your Login Code</h1>
        <p style="color: #5a6a80; font-size: 16px; margin-bottom: 32px;">Hi <strong>${student.name}</strong>, use this code to log in to VoteTrack:</p>
        <div style="background: #e8edf5; border-radius: 12px; padding: 32px; text-align: center; margin-bottom: 32px;">
          <span style="font-size: 48px; font-weight: 700; letter-spacing: 12px; color: #1e3a5f;">${otp}</span>
        </div>
        <p style="color: #5a6a80; font-size: 14px;">This code expires in 10 minutes. Do not share it with anyone.</p>
      </div>
    `);

    return c.json({ success: true, message: "OTP sent to your email" });
  } catch (e) {
    console.log("auth/request-otp error:", e);
    return c.json({ error: "Failed to send OTP" }, 500);
  }
});

// POST /auth/verify-otp
app.post("/make-server-1c5486f2/auth/verify-otp", async (c) => {
  try {
    const { email, studentId, otp } = await c.req.json();
    if (!email || !studentId || !otp) return c.json({ error: "Email, student ID, and OTP required" }, 400);
    const stored = await kv.get(`otp:${email}:${studentId.toUpperCase()}`) as any;
    if (!stored) return c.json({ error: "No OTP found. Please request a new one." }, 404);
    if (stored.expires < Date.now()) {
      await kv.del(`otp:${email}:${studentId.toUpperCase()}`);
      return c.json({ error: "OTP has expired. Please request a new one." }, 410);
    }
    if (stored.code !== otp) return c.json({ error: "Invalid OTP" }, 401);

    await kv.del(`otp:${email}:${studentId.toUpperCase()}`);

    const student = await kv.get(`student:${stored.studentId}`) as any;
    const token = generateToken();
    await kv.set(`auth:${token}`, {
      userId: student.id,
      role: "student",
      schoolId: student.schoolId,
      schoolPrefix: student.schoolPrefix,
      expires: Date.now() + 8 * 60 * 60 * 1000,
    });

    return c.json({
      token,
      role: "student",
      student: { id: student.id, name: student.name, email: student.email, studentId: student.studentId, schoolPrefix: student.schoolPrefix },
    });
  } catch (e) {
    console.log("auth/verify-otp error:", e);
    return c.json({ error: "Verification failed" }, 500);
  }
});

// POST /auth/logout
app.post("/make-server-1c5486f2/auth/logout", async (c) => {
  const authHeader = c.req.header("Authorization");
  if (authHeader?.startsWith("Bearer ")) {
    await kv.del(`auth:${authHeader.split(" ")[1]}`);
  }
  return c.json({ success: true });
});

// ─── Candidates (School Admin manages) ───────────────────────────────────────

// POST /school-admin/candidates
app.post("/make-server-1c5486f2/school-admin/candidates", async (c) => {
  const session = await getAuthSession(c.req.header("Authorization"));
  if (!session || session.role !== "school_admin") return c.json({ error: "Unauthorized" }, 401);
  try {
    const { name, email, sessionId, position } = await c.req.json();
    if (!name || !email || !sessionId) return c.json({ error: "Name, email, and session ID required" }, 400);
    const votingSession = await kv.get(`session:${sessionId}`) as any;
    if (!votingSession || votingSession.schoolId !== session.schoolId) return c.json({ error: "Session not found" }, 404);

    const id = crypto.randomUUID();
    const pitchToken = generateToken();
    const candidate = { id, name, email, sessionId, schoolId: session.schoolId, position: position || "Candidate", pitch: "", photo: "", verified: false, createdAt: Date.now() };
    await kv.set(`candidate:${id}`, candidate);
    await kv.set(`token:${pitchToken}`, { type: "candidate_pitch", candidateId: id, expires: Date.now() + 7 * 24 * 60 * 60 * 1000 });

    const sessionCandidates = (await kv.get(`session:${sessionId}:candidates`) as string[]) || [];
    sessionCandidates.push(id);
    await kv.set(`session:${sessionId}:candidates`, sessionCandidates);

    const school = await kv.get(`school:${session.schoolId}`) as any;
    const pitchUrl = `${APP_URL}/candidate/verify/${pitchToken}`;
    await sendEmail(email, `You've been nominated — ${votingSession.title}`, `
      <div style="font-family: Inter, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        <h1 style="color: #1e3a5f; font-size: 28px; margin-bottom: 8px;">You've Been Nominated</h1>
        <p style="color: #5a6a80; font-size: 16px; margin-bottom: 8px;">Hi <strong>${name}</strong>,</p>
        <p style="color: #0f1923; font-size: 16px; margin-bottom: 24px;">You have been registered as a candidate for <strong>${votingSession.title}</strong> at <strong>${school.name}</strong>.</p>
        <p style="color: #0f1923; font-size: 16px; margin-bottom: 24px;">Please click the link below to verify your candidacy and submit your election pitch:</p>
        <a href="${pitchUrl}" style="display: inline-block; background: #1e3a5f; color: #ffffff; padding: 14px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 16px;">Submit My Pitch</a>
        <p style="color: #5a6a80; font-size: 13px; margin-top: 32px;">This link expires in 7 days.</p>
      </div>
    `);

    return c.json({ success: true, candidate });
  } catch (e) {
    console.log("school-admin/candidates POST error:", e);
    return c.json({ error: "Failed to register candidate" }, 500);
  }
});

// GET /school-admin/candidates
app.get("/make-server-1c5486f2/school-admin/candidates", async (c) => {
  const session = await getAuthSession(c.req.header("Authorization"));
  if (!session || session.role !== "school_admin") return c.json({ error: "Unauthorized" }, 401);
  const sessionParam = c.req.query("sessionId");
  if (sessionParam) {
    const ids = (await kv.get(`session:${sessionParam}:candidates`) as string[]) || [];
    const candidates = (await kv.mget(ids.map(id => `candidate:${id}`))).filter(Boolean);
    return c.json({ candidates });
  }
  const sessionIds = (await kv.get(`school:${session.schoolId}:sessions`) as string[]) || [];
  const allCandidates: any[] = [];
  for (const sid of sessionIds) {
    const ids = (await kv.get(`session:${sid}:candidates`) as string[]) || [];
    const candidates = (await kv.mget(ids.map(id => `candidate:${id}`))).filter(Boolean);
    allCandidates.push(...candidates);
  }
  return c.json({ candidates: allCandidates });
});

// GET /verify/candidate/:token — get candidate info for pitch form
app.get("/make-server-1c5486f2/verify/candidate/:token", async (c) => {
  const token = c.req.param("token");
  const tokenData = await kv.get(`token:${token}`) as any;
  if (!tokenData || tokenData.type !== "candidate_pitch" || tokenData.expires < Date.now()) {
    return c.json({ error: "Invalid or expired link" }, 400);
  }
  const candidate = await kv.get(`candidate:${tokenData.candidateId}`) as any;
  if (!candidate) return c.json({ error: "Candidate not found" }, 404);
  const votingSession = await kv.get(`session:${candidate.sessionId}`) as any;
  const school = await kv.get(`school:${candidate.schoolId}`) as any;
  return c.json({ valid: true, candidate, session: votingSession, school, token });
});

// POST /verify/candidate/:token — submit pitch
app.post("/make-server-1c5486f2/verify/candidate/:token", async (c) => {
  const token = c.req.param("token");
  const tokenData = await kv.get(`token:${token}`) as any;
  if (!tokenData || tokenData.type !== "candidate_pitch" || tokenData.expires < Date.now()) {
    return c.json({ error: "Invalid or expired link" }, 400);
  }
  try {
    const { pitch, photo } = await c.req.json();
    if (!pitch) return c.json({ error: "Pitch is required" }, 400);
    const candidate = await kv.get(`candidate:${tokenData.candidateId}`) as any;
    if (!candidate) return c.json({ error: "Candidate not found" }, 404);
    candidate.pitch = pitch;
    candidate.photo = photo || "";
    candidate.verified = true;
    await kv.set(`candidate:${candidate.id}`, candidate);
    await kv.del(`token:${token}`);
    return c.json({ success: true, message: "Pitch submitted successfully" });
  } catch (e) {
    console.log("verify/candidate POST error:", e);
    return c.json({ error: "Failed to submit pitch" }, 500);
  }
});

// ─── Voting Sessions ──────────────────────────────────────────────────────────

// POST /school-admin/sessions
app.post("/make-server-1c5486f2/school-admin/sessions", async (c) => {
  const session = await getAuthSession(c.req.header("Authorization"));
  if (!session || session.role !== "school_admin") return c.json({ error: "Unauthorized" }, 401);
  try {
    const { title, description, startDate, endDate } = await c.req.json();
    if (!title || !startDate || !endDate) return c.json({ error: "Title, start date, and end date required" }, 400);
    const id = crypto.randomUUID();
    const votingSession = { id, title, description: description || "", schoolId: session.schoolId, startDate, endDate, status: "upcoming", createdAt: Date.now() };
    await kv.set(`session:${id}`, votingSession);
    const sessionIds = (await kv.get(`school:${session.schoolId}:sessions`) as string[]) || [];
    sessionIds.push(id);
    await kv.set(`school:${session.schoolId}:sessions`, sessionIds);
    return c.json({ success: true, session: votingSession });
  } catch (e) {
    console.log("school-admin/sessions POST error:", e);
    return c.json({ error: "Failed to create session" }, 500);
  }
});

// GET /school-admin/sessions
app.get("/make-server-1c5486f2/school-admin/sessions", async (c) => {
  const session = await getAuthSession(c.req.header("Authorization"));
  if (!session || session.role !== "school_admin") return c.json({ error: "Unauthorized" }, 401);
  const sessionIds = (await kv.get(`school:${session.schoolId}:sessions`) as string[]) || [];
  const sessions = (await kv.mget(sessionIds.map(id => `session:${id}`))).filter(Boolean).map((s: any) => {
    const now = Date.now();
    const start = new Date(s.startDate).getTime();
    const end = new Date(s.endDate).getTime();
    s.status = now < start ? "upcoming" : now > end ? "completed" : "ongoing";
    return s;
  });
  return c.json({ sessions });
});

// PUT /school-admin/sessions/:id
app.put("/make-server-1c5486f2/school-admin/sessions/:id", async (c) => {
  const authSession = await getAuthSession(c.req.header("Authorization"));
  if (!authSession || authSession.role !== "school_admin") return c.json({ error: "Unauthorized" }, 401);
  const id = c.req.param("id");
  try {
    const updates = await c.req.json();
    const votingSession = await kv.get(`session:${id}`) as any;
    if (!votingSession || votingSession.schoolId !== authSession.schoolId) return c.json({ error: "Session not found" }, 404);
    const updated = { ...votingSession, ...updates };
    await kv.set(`session:${id}`, updated);
    return c.json({ success: true, session: updated });
  } catch (e) {
    return c.json({ error: "Failed to update session" }, 500);
  }
});

// ─── Student — Sessions & Voting ──────────────────────────────────────────────

// GET /student/sessions
app.get("/make-server-1c5486f2/student/sessions", async (c) => {
  const session = await getAuthSession(c.req.header("Authorization"));
  if (!session || session.role !== "student") return c.json({ error: "Unauthorized" }, 401);
  const sessionIds = (await kv.get(`school:${session.schoolId}:sessions`) as string[]) || [];
  const now = Date.now();
  const sessions = (await kv.mget(sessionIds.map(id => `session:${id}`))).filter(Boolean).map((s: any) => {
    const start = new Date(s.startDate).getTime();
    const end = new Date(s.endDate).getTime();
    s.status = now < start ? "upcoming" : now > end ? "completed" : "ongoing";
    return s;
  });
  return c.json({ sessions });
});

// GET /student/session/:id
app.get("/make-server-1c5486f2/student/session/:id", async (c) => {
  const authSession = await getAuthSession(c.req.header("Authorization"));
  if (!authSession || authSession.role !== "student") return c.json({ error: "Unauthorized" }, 401);
  const id = c.req.param("id");
  const votingSession = await kv.get(`session:${id}`) as any;
  if (!votingSession || votingSession.schoolId !== authSession.schoolId) return c.json({ error: "Session not found" }, 404);
  const now = Date.now();
  const start = new Date(votingSession.startDate).getTime();
  const end = new Date(votingSession.endDate).getTime();
  votingSession.status = now < start ? "upcoming" : now > end ? "completed" : "ongoing";

  const candidateIds = (await kv.get(`session:${id}:candidates`) as string[]) || [];
  const candidates = (await kv.mget(candidateIds.map(cid => `candidate:${cid}`))).filter(Boolean);
  const hasVoted = !!(await kv.get(`vote:${id}:${authSession.userId}`));

  return c.json({ session: votingSession, candidates, hasVoted });
});

// POST /student/vote
app.post("/make-server-1c5486f2/student/vote", async (c) => {
  const authSession = await getAuthSession(c.req.header("Authorization"));
  if (!authSession || authSession.role !== "student") return c.json({ error: "Unauthorized" }, 401);
  try {
    const { sessionId, candidateId } = await c.req.json();
    if (!sessionId || !candidateId) return c.json({ error: "Session ID and candidate ID required" }, 400);

    const votingSession = await kv.get(`session:${sessionId}`) as any;
    if (!votingSession || votingSession.schoolId !== authSession.schoolId) return c.json({ error: "Session not found" }, 404);
    const now = Date.now();
    const start = new Date(votingSession.startDate).getTime();
    const end = new Date(votingSession.endDate).getTime();
    if (now < start || now > end) return c.json({ error: "Voting is not currently open for this session" }, 400);

    const existingVote = await kv.get(`vote:${sessionId}:${authSession.userId}`);
    if (existingVote) return c.json({ error: "You have already voted in this session" }, 409);

    const candidate = await kv.get(`candidate:${candidateId}`) as any;
    if (!candidate || candidate.sessionId !== sessionId) return c.json({ error: "Candidate not found in this session" }, 404);

    await kv.set(`vote:${sessionId}:${authSession.userId}`, { candidateId, votedAt: Date.now() });

    const currentCount = ((await kv.get(`session:${sessionId}:votes:${candidateId}`)) as number) || 0;
    await kv.set(`session:${sessionId}:votes:${candidateId}`, currentCount + 1);

    const student = await kv.get(`student:${authSession.userId}`) as any;
    await sendEmail(student.email, `Your vote has been recorded — ${votingSession.title}`, `
      <div style="font-family: Inter, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        <div style="background: #1e3a5f; border-radius: 12px; padding: 40px; text-align: center; margin-bottom: 32px;">
          <h1 style="color: #ffffff; font-size: 28px; margin: 0 0 8px;">Vote Confirmed!</h1>
          <p style="color: rgba(255,255,255,0.8); font-size: 16px; margin: 0;">Your voice has been heard.</p>
        </div>
        <p style="color: #0f1923; font-size: 16px; margin-bottom: 8px;">Hi <strong>${student.name}</strong>,</p>
        <p style="color: #5a6a80; font-size: 16px; margin-bottom: 24px;">
          Your vote for <strong>${candidate.name}</strong> in <strong>${votingSession.title}</strong> has been successfully recorded.
        </p>
        <p style="color: #5a6a80; font-size: 14px;">Thank you for participating in your school's democratic process.</p>
      </div>
    `);

    return c.json({ success: true, message: `Vote for ${candidate.name} recorded successfully` });
  } catch (e) {
    console.log("student/vote error:", e);
    return c.json({ error: "Failed to record vote" }, 500);
  }
});

// GET /student/results/:sessionId
app.get("/make-server-1c5486f2/student/results/:sessionId", async (c) => {
  const authSession = await getAuthSession(c.req.header("Authorization"));
  if (!authSession || authSession.role !== "student") return c.json({ error: "Unauthorized" }, 401);
  const sessionId = c.req.param("sessionId");
  const votingSession = await kv.get(`session:${sessionId}`) as any;
  if (!votingSession || votingSession.schoolId !== authSession.schoolId) return c.json({ error: "Session not found" }, 404);

  const candidateIds = (await kv.get(`session:${sessionId}:candidates`) as string[]) || [];
  const candidates = await kv.mget(candidateIds.map(cid => `candidate:${cid}`));
  const voteCounts = await kv.mget(candidateIds.map(cid => `session:${sessionId}:votes:${cid}`));

  const results = candidates.filter(Boolean).map((c: any, i: number) => ({
    id: c.id,
    name: c.name,
    position: c.position,
    photo: c.photo,
    votes: (voteCounts[i] as number) || 0,
  }));

  const totalVotes = results.reduce((sum, r) => sum + r.votes, 0);
  const hasVoted = !!(await kv.get(`vote:${sessionId}:${authSession.userId}`));

  return c.json({ session: votingSession, results, totalVotes, hasVoted });
});

// GET /school-admin/results/:sessionId
app.get("/make-server-1c5486f2/school-admin/results/:sessionId", async (c) => {
  const authSession = await getAuthSession(c.req.header("Authorization"));
  if (!authSession || authSession.role !== "school_admin") return c.json({ error: "Unauthorized" }, 401);
  const sessionId = c.req.param("sessionId");
  const votingSession = await kv.get(`session:${sessionId}`) as any;
  if (!votingSession || votingSession.schoolId !== authSession.schoolId) return c.json({ error: "Session not found" }, 404);

  const candidateIds = (await kv.get(`session:${sessionId}:candidates`) as string[]) || [];
  const candidates = await kv.mget(candidateIds.map(cid => `candidate:${cid}`));
  const voteCounts = await kv.mget(candidateIds.map(cid => `session:${sessionId}:votes:${cid}`));

  const results = candidates.filter(Boolean).map((c: any, i: number) => ({
    id: c.id,
    name: c.name,
    position: c.position,
    photo: c.photo,
    votes: (voteCounts[i] as number) || 0,
  }));

  const totalVotes = results.reduce((sum, r) => sum + r.votes, 0);
  return c.json({ session: votingSession, results, totalVotes });
});

Deno.serve(app.fetch);
