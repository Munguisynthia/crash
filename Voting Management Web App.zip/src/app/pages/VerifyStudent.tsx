import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router";
import { api } from "../lib/api";
import { AuthLayout } from "../components/Layout";
import { CheckCircle, XCircle, Loader2 } from "lucide-react";

export function VerifyStudent() {
  const { token } = useParams<{ token: string }>();
  const navigate = useNavigate();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [studentId, setStudentId] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!token) return;
    api.verifyStudent(token)
      .then(res => {
        setStudentId(res.studentId);
        setStatus("success");
      })
      .catch(err => {
        setMessage(err.message);
        setStatus("error");
      });
  }, [token]);

  return (
    <AuthLayout>
      <div className="bg-card rounded-2xl shadow-sm border border-border p-8 text-center">
        {status === "loading" && (
          <>
            <Loader2 className="w-12 h-12 animate-spin text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-bold text-foreground mb-2">Verifying your account…</h2>
            <p className="text-muted-foreground text-sm">Please wait while we confirm your registration.</p>
          </>
        )}
        {status === "success" && (
          <>
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Account Verified!</h2>
            <p className="text-muted-foreground text-sm mb-1">Your student account has been successfully verified.</p>
            {studentId && <p className="font-mono font-bold text-primary text-lg mb-5">{studentId}</p>}
            <p className="text-muted-foreground text-sm mb-6">You can now log in to VoteTrack using your email and student ID.</p>
            <button
              onClick={() => navigate("/")}
              className="bg-primary text-primary-foreground px-6 py-2.5 rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity"
            >
              Go to Login
            </button>
          </>
        )}
        {status === "error" && (
          <>
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Verification Failed</h2>
            <p className="text-muted-foreground text-sm mb-6">{message || "This verification link is invalid or has expired."}</p>
            <button
              onClick={() => navigate("/")}
              className="bg-primary text-primary-foreground px-6 py-2.5 rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity"
            >
              Go to Login
            </button>
          </>
        )}
      </div>
    </AuthLayout>
  );
}
