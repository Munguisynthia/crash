import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Layout } from "../components/Layout";
import { api } from "../lib/api";
import { Plus, Calendar, Play, Clock, CheckCircle, BarChart2, Loader2, X } from "lucide-react";

function SessionModal({ onClose, onCreated }: { onClose: () => void; onCreated: (s: any) => void }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await api.createSession({ title, description, startDate, endDate });
      onCreated(res.session);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-2xl shadow-xl border border-border w-full max-w-lg">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h3 className="font-bold text-foreground">New Voting Session</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Session Title *</label>
            <input type="text" value={title} onChange={e => setTitle(e.target.value)} required className="w-full px-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" placeholder="e.g. Student Council President Election 2024" />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Description</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} className="w-full px-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none" placeholder="Optional description of the election…" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Start Date & Time *</label>
              <input type="datetime-local" value={startDate} onChange={e => setStartDate(e.target.value)} required className="w-full px-3 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">End Date & Time *</label>
              <input type="datetime-local" value={endDate} onChange={e => setEndDate(e.target.value)} required className="w-full px-3 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
          </div>
          {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg">{error}</div>}
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 bg-secondary text-secondary-foreground py-2.5 rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity">Cancel</button>
            <button type="submit" disabled={loading} className="flex-1 bg-primary text-primary-foreground py-2.5 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-60">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Create Session"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export function ManageSessions() {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    api.getAdminSessions().then(r => setSessions(r.sessions)).catch(console.error).finally(() => setLoading(false));
  }, []);

  const statusConfig: Record<string, any> = {
    ongoing: { icon: Play, color: "text-green-600", bg: "bg-green-100", label: "Live" },
    upcoming: { icon: Clock, color: "text-blue-600", bg: "bg-blue-100", label: "Upcoming" },
    completed: { icon: CheckCircle, color: "text-gray-500", bg: "bg-gray-100", label: "Completed" },
  };

  return (
    <Layout title="Voting Sessions" breadcrumb="Sessions">
      <div className="flex items-center justify-between mb-6">
        <p className="text-sm text-muted-foreground">{sessions.length} session{sessions.length !== 1 ? "s" : ""} total</p>
        <button
          onClick={() => setShowModal(true)}
          className="bg-primary text-primary-foreground px-4 py-2.5 rounded-lg font-semibold text-sm flex items-center gap-2 hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" /> New Session
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-40"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div>
      ) : sessions.length === 0 ? (
        <div className="text-center py-20 bg-card border border-border rounded-xl">
          <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-semibold text-foreground mb-2">No Sessions Yet</h3>
          <p className="text-muted-foreground text-sm mb-4">Create your first voting session to get started.</p>
          <button onClick={() => setShowModal(true)} className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition-opacity">
            Create Session
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {sessions.map(session => {
            const cfg = statusConfig[session.status] || statusConfig.upcoming;
            const Icon = cfg.icon;
            return (
              <div key={session.id} className="bg-card border border-border rounded-xl p-5 flex items-center gap-4 hover:shadow-sm transition-shadow">
                <div className={`w-10 h-10 ${cfg.bg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                  <Icon className={`w-5 h-5 ${cfg.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <h3 className="font-semibold text-foreground truncate">{session.title}</h3>
                    <span className={`text-xs font-semibold ${cfg.color} ${cfg.bg} px-2 py-0.5 rounded-full flex-shrink-0`}>{cfg.label}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {new Date(session.startDate).toLocaleString()} → {new Date(session.endDate).toLocaleString()}
                  </p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    onClick={() => navigate(`/school-admin/candidates?sessionId=${session.id}`)}
                    className="text-xs font-medium text-muted-foreground hover:text-foreground px-3 py-1.5 rounded-lg hover:bg-muted transition-colors"
                  >
                    Candidates
                  </button>
                  <button
                    onClick={() => navigate(`/session/${session.id}/results`)}
                    className="flex items-center gap-1.5 text-xs font-medium text-accent px-3 py-1.5 rounded-lg hover:bg-blue-50 transition-colors"
                  >
                    <BarChart2 className="w-3.5 h-3.5" /> Results
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showModal && (
        <SessionModal
          onClose={() => setShowModal(false)}
          onCreated={s => { setSessions(prev => [s, ...prev]); setShowModal(false); }}
        />
      )}
    </Layout>
  );
}
