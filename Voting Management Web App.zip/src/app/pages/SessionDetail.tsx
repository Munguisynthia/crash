import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { Layout } from "../components/Layout";
import { api } from "../lib/api";
import { CheckCircle, Clock, ChevronRight, Loader2, UserCheck, BarChart2, AlertCircle } from "lucide-react";

interface Candidate {
  id: string;
  name: string;
  position: string;
  pitch: string;
  photo: string;
}

export function SessionDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;
    api.getSession(id)
      .then(res => setData(res))
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return <Layout title="Loading..."><div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div></Layout>;
  }

  if (error || !data) {
    return <Layout title="Error"><div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{error || "Session not found"}</div></Layout>;
  }

  const { session, candidates, hasVoted } = data;
  const isOngoing = session.status === "ongoing";
  const isCompleted = session.status === "completed";

  return (
    <Layout title={session.title} breadcrumb="Sessions">
      {/* Status banner */}
      {hasVoted && (
        <div className="bg-green-50 border border-green-200 rounded-xl px-5 py-4 flex items-center gap-3 mb-6">
          <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
          <div>
            <p className="font-semibold text-green-800 text-sm">You've already voted in this session</p>
            <p className="text-green-700 text-xs mt-0.5">Your vote has been recorded. You can view live results.</p>
          </div>
          <button
            onClick={() => navigate(`/session/${id}/results`)}
            className="ml-auto flex items-center gap-1.5 text-sm font-semibold text-green-700 hover:text-green-900 transition-colors"
          >
            View Results <BarChart2 className="w-4 h-4" />
          </button>
        </div>
      )}

      {!isOngoing && !isCompleted && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl px-5 py-4 flex items-center gap-3 mb-6">
          <Clock className="w-5 h-5 text-blue-600 flex-shrink-0" />
          <p className="text-blue-800 text-sm font-medium">
            Voting opens on {new Date(session.startDate).toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
          </p>
        </div>
      )}

      {isCompleted && (
        <div className="bg-gray-50 border border-border rounded-xl px-5 py-4 flex items-center gap-3 mb-6">
          <AlertCircle className="w-5 h-5 text-muted-foreground flex-shrink-0" />
          <p className="text-muted-foreground text-sm font-medium">This election has ended.</p>
          <button
            onClick={() => navigate(`/session/${id}/results`)}
            className="ml-auto flex items-center gap-1.5 text-sm font-semibold text-accent hover:opacity-80 transition-opacity"
          >
            View Results <BarChart2 className="w-4 h-4" />
          </button>
        </div>
      )}

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-foreground">Candidates ({candidates.length})</h2>
          {isOngoing && !hasVoted && (
            <span className="text-sm text-muted-foreground">Click a candidate to vote</span>
          )}
        </div>

        {candidates.length === 0 ? (
          <div className="text-center py-16 bg-card border border-border rounded-xl">
            <UserCheck className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground text-sm">No candidates registered yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {candidates.map((candidate: Candidate) => (
              <button
                key={candidate.id}
                onClick={() => {
                  if (isOngoing && !hasVoted) navigate(`/session/${id}/vote/${candidate.id}`);
                  else if (isCompleted || hasVoted) navigate(`/session/${id}/results`);
                }}
                disabled={!isOngoing && !isCompleted && !hasVoted}
                className="bg-card border border-border rounded-xl p-5 text-left hover:shadow-md hover:border-accent/30 transition-all group disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="w-14 h-14 bg-secondary rounded-full flex items-center justify-center mb-4 text-2xl font-bold text-primary">
                  {candidate.photo ? (
                    <img src={candidate.photo} alt={candidate.name} className="w-full h-full object-cover rounded-full" />
                  ) : (
                    candidate.name.charAt(0).toUpperCase()
                  )}
                </div>
                <h3 className="font-semibold text-foreground text-base group-hover:text-accent transition-colors">{candidate.name}</h3>
                <p className="text-xs text-muted-foreground mb-3">{candidate.position}</p>
                {candidate.pitch && (
                  <p className="text-sm text-muted-foreground line-clamp-3">{candidate.pitch}</p>
                )}
                {isOngoing && !hasVoted && (
                  <div className="flex items-center gap-1 mt-4 text-xs font-semibold text-accent">
                    Vote for {candidate.name.split(" ")[0]} <ChevronRight className="w-3.5 h-3.5" />
                  </div>
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
