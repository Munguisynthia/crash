import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { Layout } from "../components/Layout";
import { api } from "../lib/api";
import { CheckCircle, ArrowLeft, Loader2, ShieldCheck, AlertTriangle } from "lucide-react";

export function VotePage() {
  const { id: sessionId, candidateId } = useParams<{ id: string; candidateId: string }>();
  const navigate = useNavigate();
  const [data, setData] = useState<any>(null);
  const [candidate, setCandidate] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [voting, setVoting] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!sessionId) return;
    api.getSession(sessionId)
      .then(res => {
        setData(res);
        const found = res.candidates.find((c: any) => c.id === candidateId);
        if (!found) setError("Candidate not found in this session");
        else setCandidate(found);
      })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [sessionId, candidateId]);

  const handleVote = async () => {
    if (!sessionId || !candidateId) return;
    setVoting(true);
    setError("");
    try {
      await api.vote(sessionId, candidateId);
      setConfirmed(true);
      setTimeout(() => navigate(`/session/${sessionId}/results`), 3000);
    } catch (err: any) {
      setError(err.message);
      setVoting(false);
    }
  };

  if (loading) {
    return <Layout title="Loading..."><div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div></Layout>;
  }

  if (confirmed) {
    return (
      <Layout title="Vote Confirmed">
        <div className="max-w-md mx-auto text-center py-16">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Vote Recorded!</h2>
          <p className="text-muted-foreground mb-2">Your vote for <strong className="text-foreground">{candidate?.name}</strong> has been recorded.</p>
          <p className="text-muted-foreground text-sm mb-6">A confirmation email has been sent to you. Redirecting to results…</p>
          <div className="flex gap-2 justify-center">
            <div className="w-2 h-2 bg-accent rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
            <div className="w-2 h-2 bg-accent rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
            <div className="w-2 h-2 bg-accent rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Confirm Your Vote" breadcrumb="Vote">
      <div className="max-w-lg mx-auto">
        <button
          onClick={() => navigate(`/session/${sessionId}`)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back to candidates
        </button>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg mb-5 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}

        {candidate && data && (
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="bg-primary px-6 py-8 text-center">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl font-bold text-white">
                {candidate.photo ? (
                  <img src={candidate.photo} alt={candidate.name} className="w-full h-full object-cover rounded-full" />
                ) : (
                  candidate.name.charAt(0).toUpperCase()
                )}
              </div>
              <h2 className="text-2xl font-bold text-white">{candidate.name}</h2>
              <p className="text-white/70 text-sm mt-1">{candidate.position}</p>
            </div>

            <div className="p-6">
              {candidate.pitch && (
                <div className="mb-6">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Election Pitch</h3>
                  <p className="text-foreground text-sm leading-relaxed">{candidate.pitch}</p>
                </div>
              )}

              <div className="bg-secondary/50 border border-border rounded-xl p-4 mb-6">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-foreground text-sm">Confirm your vote</p>
                    <p className="text-muted-foreground text-xs mt-0.5">
                      You are voting for <strong>{candidate.name}</strong> in <strong>{data.session.title}</strong>. This action cannot be undone — each student may only vote once.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => navigate(`/session/${sessionId}`)}
                  className="flex-1 bg-secondary text-secondary-foreground py-2.5 px-4 rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity"
                >
                  Cancel
                </button>
                <button
                  onClick={handleVote}
                  disabled={voting}
                  className="flex-1 bg-primary text-primary-foreground py-2.5 px-4 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-60"
                >
                  {voting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Confirm Vote"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
