import { useState, useEffect } from "react";
import { Layout } from "../components/Layout";
import { api } from "../lib/api";
import { Plus, School, CheckCircle, Clock, Loader2, X, Mail, Hash } from "lucide-react";

function SchoolModal({ onClose, onCreated }: { onClose: () => void; onCreated: (s: any) => void }) {
  const [name, setName] = useState("");
  const [govId, setGovId] = useState("");
  const [email, setEmail] = useState("");
  const [studentPrefix, setStudentPrefix] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (studentPrefix.length !== 4) { setError("Student ID prefix must be exactly 4 characters"); return; }
    setError("");
    setLoading(true);
    try {
      const res = await api.createSchool({ name, govId: govId.trim(), email: email.trim(), studentPrefix: studentPrefix.toUpperCase() });
      onCreated(res.school);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-card rounded-2xl shadow-xl border border-border w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h3 className="font-bold text-foreground">Register New School</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors"><X className="w-5 h-5" /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">School Name *</label>
            <input type="text" value={name} onChange={e => setName(e.target.value)} required className="w-full px-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" placeholder="Greenfield Academy" />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">
              <span className="flex items-center gap-1.5"><Hash className="w-3.5 h-3.5" />Government Registration ID *</span>
            </label>
            <input type="text" value={govId} onChange={e => setGovId(e.target.value)} required className="w-full px-4 py-2.5 bg-input-background border border-border rounded-lg text-sm font-mono focus:outline-none focus:ring-2 focus:ring-ring" placeholder="GOV-2024-001234" />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">
              <span className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5" />School Email Address *</span>
            </label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full px-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" placeholder="admin@greenfield.edu" />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Student ID Prefix * <span className="text-muted-foreground font-normal">(4 letters, unique per school)</span></label>
            <input
              type="text"
              value={studentPrefix}
              onChange={e => setStudentPrefix(e.target.value.toUpperCase().replace(/[^A-Z]/g, "").slice(0, 4))}
              required
              maxLength={4}
              className="w-full px-4 py-2.5 bg-input-background border border-border rounded-lg text-sm font-mono tracking-widest focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder="GRFD"
            />
            <p className="text-xs text-muted-foreground mt-1">e.g. "GRFD" → student IDs start with GRFD2024001</p>
          </div>
          {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg">{error}</div>}
          <p className="text-xs text-muted-foreground bg-blue-50 border border-blue-200 rounded-lg px-3 py-2">
            An access link will be emailed to the school to set up their admin account.
          </p>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 bg-secondary text-secondary-foreground py-2.5 rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity">Cancel</button>
            <button type="submit" disabled={loading} className="flex-1 bg-primary text-primary-foreground py-2.5 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-60">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Register School"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export function SystemAdminDashboard() {
  const [schools, setSchools] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    api.getSchools().then(r => setSchools(r.schools)).catch(console.error).finally(() => setLoading(false));
  }, []);

  return (
    <Layout title="School Management" breadcrumb="Schools">
      <div className="flex items-center justify-between mb-6">
        <div>
          <p className="text-sm text-muted-foreground">{schools.length} school{schools.length !== 1 ? "s" : ""} registered on the platform</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-primary text-primary-foreground px-4 py-2.5 rounded-lg font-semibold text-sm flex items-center gap-2 hover:opacity-90 transition-opacity"
        >
          <Plus className="w-4 h-4" /> Add School
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-40"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div>
      ) : schools.length === 0 ? (
        <div className="text-center py-24 bg-card border border-border rounded-xl">
          <School className="w-14 h-14 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-semibold text-foreground text-lg mb-2">No Schools Registered</h3>
          <p className="text-muted-foreground text-sm mb-5">Add the first school to start managing elections across your platform.</p>
          <button onClick={() => setShowModal(true)} className="bg-primary text-primary-foreground px-5 py-2.5 rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity">
            Add First School
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {schools.map(school => (
            <div key={school.id} className="bg-card border border-border rounded-xl p-5 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-base font-bold text-primary flex-shrink-0">
                  {school.name.charAt(0)}
                </div>
                {school.verified ? (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-green-700 bg-green-100 px-2.5 py-1 rounded-full">
                    <CheckCircle className="w-3 h-3" /> Active
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-orange-700 bg-orange-100 px-2.5 py-1 rounded-full">
                    <Clock className="w-3 h-3" /> Pending Setup
                  </span>
                )}
              </div>
              <h3 className="font-bold text-foreground mb-1">{school.name}</h3>
              <p className="text-xs text-muted-foreground mb-3">{school.email}</p>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="bg-secondary px-2 py-1 rounded font-mono font-semibold text-foreground">{school.studentPrefix}****</span>
                <span>Gov ID: {school.govId}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-3">
                Registered {new Date(school.createdAt).toLocaleDateString()}
              </p>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <SchoolModal
          onClose={() => setShowModal(false)}
          onCreated={s => { setSchools(prev => [s, ...prev]); setShowModal(false); }}
        />
      )}
    </Layout>
  );
}
