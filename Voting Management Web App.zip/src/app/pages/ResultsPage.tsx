import { useState, useEffect, useCallback } from "react";
import { useParams } from "react-router";
import { Layout } from "../components/Layout";
import { api, getStoredRole } from "../lib/api";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Trophy, RefreshCw, Loader2, Users } from "lucide-react";

const COLORS = ["#2563eb", "#16a34a", "#d97706", "#9333ea", "#dc2626", "#0891b2"];

export function ResultsPage() {
  const { id: sessionId } = useParams<{ id: string }>();
  const role = getStoredRole();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchResults = useCallback(async () => {
    if (!sessionId) return;
    try {
      const res = role === "school_admin"
        ? await api.getAdminResults(sessionId)
        : await api.getResults(sessionId);
      setData(res);
      setLastUpdated(new Date());
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [sessionId, role]);

  useEffect(() => {
    fetchResults();
    const interval = setInterval(fetchResults, 15000);
    return () => clearInterval(interval);
  }, [fetchResults]);

  if (loading) {
    return <Layout title="Results"><div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div></Layout>;
  }

  if (error || !data) {
    return <Layout title="Results"><div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{error || "Results not available"}</div></Layout>;
  }

  const { session, results, totalVotes } = data;
  const sorted = [...results].sort((a, b) => b.votes - a.votes);
  const leader = sorted[0];

  const chartData = sorted.map((r: any) => ({
    name: r.name.split(" ")[0],
    fullName: r.name,
    votes: r.votes,
    pct: totalVotes > 0 ? ((r.votes / totalVotes) * 100).toFixed(1) : "0",
  }));

  return (
    <Layout title={`Results — ${session.title}`} breadcrumb="Results">
      {/* Header stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-card border border-border rounded-xl p-5">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Total Votes Cast</p>
          <p className="text-3xl font-bold text-foreground">{totalVotes}</p>
        </div>
        <div className="bg-card border border-border rounded-xl p-5">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Candidates</p>
          <p className="text-3xl font-bold text-foreground">{results.length}</p>
        </div>
        <div className="bg-primary rounded-xl p-5 flex items-center gap-4">
          <Trophy className="w-8 h-8 text-yellow-300 flex-shrink-0" />
          <div>
            <p className="text-xs font-semibold text-white/70 uppercase tracking-wide mb-0.5">Current Leader</p>
            <p className="text-lg font-bold text-white truncate">{leader?.name || "—"}</p>
            <p className="text-white/70 text-sm">{totalVotes > 0 ? `${((leader?.votes / totalVotes) * 100).toFixed(1)}%` : "No votes yet"}</p>
          </div>
        </div>
      </div>

      {/* Bar chart */}
      <div className="bg-card border border-border rounded-xl p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-bold text-foreground">Vote Distribution</h2>
          <div className="flex items-center gap-3">
            {lastUpdated && (
              <span className="text-xs text-muted-foreground">
                Updated {lastUpdated.toLocaleTimeString()}
              </span>
            )}
            <button
              onClick={fetchResults}
              className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Refresh
            </button>
          </div>
        </div>
        {totalVotes === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Users className="w-10 h-10 mx-auto mb-3 opacity-40" />
            <p className="text-sm">No votes have been cast yet</p>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={chartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: "var(--muted-foreground)" }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip
                contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 13 }}
                formatter={(value: any, _: any, entry: any) => [`${value} votes (${entry.payload.pct}%)`, entry.payload.fullName]}
              />
              <Bar dataKey="votes" radius={[6, 6, 0, 0]}>
                {chartData.map((_: any, i: number) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Candidate table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="border-b border-border">
            <tr>
              <th className="text-left px-5 py-3.5 text-xs font-semibold text-muted-foreground uppercase tracking-wide">#</th>
              <th className="text-left px-5 py-3.5 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Candidate</th>
              <th className="text-left px-5 py-3.5 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Votes</th>
              <th className="text-left px-5 py-3.5 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Share</th>
              <th className="px-5 py-3.5" />
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {sorted.map((r: any, i: number) => (
              <tr key={r.id} className={i === 0 && totalVotes > 0 ? "bg-blue-50/50" : ""}>
                <td className="px-5 py-4 font-bold text-muted-foreground">{i + 1}</td>
                <td className="px-5 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0" style={{ background: COLORS[i % COLORS.length] }}>
                      {r.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{r.name}</p>
                      <p className="text-xs text-muted-foreground">{r.position}</p>
                    </div>
                    {i === 0 && totalVotes > 0 && <Trophy className="w-4 h-4 text-yellow-500 ml-1" />}
                  </div>
                </td>
                <td className="px-5 py-4 font-semibold text-foreground">{r.votes}</td>
                <td className="px-5 py-4 text-muted-foreground">{totalVotes > 0 ? `${((r.votes / totalVotes) * 100).toFixed(1)}%` : "—"}</td>
                <td className="px-5 py-4 w-32">
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ width: totalVotes > 0 ? `${(r.votes / totalVotes) * 100}%` : "0%", background: COLORS[i % COLORS.length] }}
                    />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="px-5 py-3 bg-muted/30 border-t border-border">
          <p className="text-xs text-muted-foreground">Results update automatically every 15 seconds</p>
        </div>
      </div>
    </Layout>
  );
}
