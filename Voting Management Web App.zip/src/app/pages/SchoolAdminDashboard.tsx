import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Layout } from "../components/Layout";
import { api, getStoredUser } from "../lib/api";
import { Users, Calendar, Vote, BarChart2, Play, Clock, CheckCircle, Loader2, ChevronRight } from "lucide-react";

export function SchoolAdminDashboard() {
  const navigate = useNavigate();
  const user = getStoredUser();
  const [sessions, setSessions] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [candidates, setCandidates] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.getAdminSessions(), api.getStudents(), api.getCandidates()])
      .then(([s, st, c]) => {
        setSessions(s.sessions);
        setStudents(st.students);
        setCandidates(c.candidates);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const ongoing = sessions.filter(s => s.status === "ongoing");
  const upcoming = sessions.filter(s => s.status === "upcoming");
  const completed = sessions.filter(s => s.status === "completed");

  if (loading) {
    return <Layout title="Dashboard"><div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div></Layout>;
  }

  const stats = [
    { label: "Total Students", value: students.length, icon: Users, color: "bg-blue-100 text-blue-700", action: () => navigate("/school-admin/students") },
    { label: "Total Candidates", value: candidates.length, icon: Vote, color: "bg-purple-100 text-purple-700", action: () => navigate("/school-admin/candidates") },
    { label: "Active Sessions", value: ongoing.length, icon: Play, color: "bg-green-100 text-green-700", action: () => navigate("/school-admin/sessions") },
    { label: "Upcoming Sessions", value: upcoming.length, icon: Clock, color: "bg-orange-100 text-orange-700", action: () => navigate("/school-admin/sessions") },
  ];

  return (
    <Layout title="Dashboard" breadcrumb="Dashboard">
      <div className="mb-6">
        <p className="text-muted-foreground text-sm">
          Welcome back, <strong className="text-foreground">{user?.name}</strong> — {user?.school?.name}
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map(({ label, value, icon: Icon, color, action }) => (
          <button
            key={label}
            onClick={action}
            className="bg-card border border-border rounded-xl p-5 text-left hover:shadow-md hover:border-accent/30 transition-all group"
          >
            <div className={`w-10 h-10 ${color} rounded-lg flex items-center justify-center mb-3`}>
              <Icon className="w-5 h-5" />
            </div>
            <p className="text-2xl font-bold text-foreground mb-0.5">{value}</p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </button>
        ))}
      </div>

      {/* Recent sessions */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <h2 className="font-bold text-foreground">Voting Sessions</h2>
          <button
            onClick={() => navigate("/school-admin/sessions")}
            className="text-sm text-accent font-medium flex items-center gap-1 hover:underline"
          >
            Manage <ChevronRight className="w-4 h-4" />
          </button>
        </div>
        {sessions.length === 0 ? (
          <div className="px-6 py-10 text-center">
            <Calendar className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground mb-3">No sessions created yet</p>
            <button
              onClick={() => navigate("/school-admin/sessions")}
              className="bg-primary text-primary-foreground px-4 py-2 rounded-lg text-sm font-semibold hover:opacity-90 transition-opacity"
            >
              Create First Session
            </button>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {sessions.slice(0, 5).map(session => {
              const Icon = session.status === "ongoing" ? Play : session.status === "upcoming" ? Clock : CheckCircle;
              const color = session.status === "ongoing" ? "text-green-600" : session.status === "upcoming" ? "text-blue-600" : "text-muted-foreground";
              return (
                <div key={session.id} className="flex items-center gap-4 px-6 py-4 hover:bg-muted/30 transition-colors">
                  <Icon className={`w-4 h-4 flex-shrink-0 ${color}`} />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground text-sm truncate">{session.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(session.startDate).toLocaleDateString()} → {new Date(session.endDate).toLocaleDateString()}
                    </p>
                  </div>
                  <button
                    onClick={() => navigate(`/session/${session.id}/results`)}
                    className="flex items-center gap-1.5 text-xs font-medium text-accent hover:underline flex-shrink-0"
                  >
                    <BarChart2 className="w-3.5 h-3.5" /> Results
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </Layout>
  );
}
