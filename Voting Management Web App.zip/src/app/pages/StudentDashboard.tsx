import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { Layout } from "../components/Layout";
import { api } from "../lib/api";
import { Clock, CheckCircle, Play, ChevronRight, Calendar, Users, Loader2 } from "lucide-react";

interface VotingSession {
  id: string;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  status: "ongoing" | "upcoming" | "completed";
}

function StatusBadge({ status }: { status: string }) {
  const config = {
    ongoing: { bg: "bg-green-100", text: "text-green-700", icon: Play, label: "Live Now" },
    upcoming: { bg: "bg-blue-100", text: "text-blue-700", icon: Clock, label: "Upcoming" },
    completed: { bg: "bg-gray-100", text: "text-gray-600", icon: CheckCircle, label: "Completed" },
  }[status] || { bg: "bg-gray-100", text: "text-gray-600", icon: Clock, label: status };

  const Icon = config.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${config.bg} ${config.text}`}>
      <Icon className="w-3 h-3" />
      {config.label}
    </span>
  );
}

function SessionCard({ session, onClick }: { session: VotingSession; onClick: () => void }) {
  const start = new Date(session.startDate);
  const end = new Date(session.endDate);
  return (
    <button
      onClick={onClick}
      className="w-full bg-card border border-border rounded-xl p-5 text-left hover:shadow-md hover:border-accent/30 transition-all group"
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <h3 className="font-semibold text-foreground text-base group-hover:text-accent transition-colors line-clamp-2">{session.title}</h3>
        <StatusBadge status={session.status} />
      </div>
      {session.description && (
        <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{session.description}</p>
      )}
      <div className="flex items-center gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{start.toLocaleDateString()}</span>
        <span>→</span>
        <span>{end.toLocaleDateString()}</span>
      </div>
      <div className="flex items-center justify-between mt-4">
        <span className="text-xs text-muted-foreground">
          {session.status === "ongoing" ? "Click to vote" : session.status === "completed" ? "View results" : "Coming soon"}
        </span>
        <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-accent transition-colors" />
      </div>
    </button>
  );
}

export function StudentDashboard() {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<VotingSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    api.getSessions()
      .then(res => setSessions(res.sessions))
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const ongoing = sessions.filter(s => s.status === "ongoing");
  const upcoming = sessions.filter(s => s.status === "upcoming");
  const completed = sessions.filter(s => s.status === "completed");

  if (loading) {
    return (
      <Layout title="Dashboard">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Dashboard" breadcrumb="Dashboard">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg mb-6">{error}</div>
      )}

      {sessions.length === 0 ? (
        <div className="text-center py-20">
          <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No Voting Sessions Yet</h3>
          <p className="text-muted-foreground text-sm">Your school hasn't created any voting sessions. Check back later.</p>
        </div>
      ) : (
        <div className="space-y-8">
          {ongoing.length > 0 && (
            <section>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <h2 className="font-bold text-foreground">Live Now</h2>
                <span className="bg-green-100 text-green-700 text-xs font-semibold px-2 py-0.5 rounded-full">{ongoing.length}</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {ongoing.map(s => (
                  <SessionCard key={s.id} session={s} onClick={() => navigate(`/session/${s.id}`)} />
                ))}
              </div>
            </section>
          )}

          {upcoming.length > 0 && (
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Clock className="w-4 h-4 text-blue-500" />
                <h2 className="font-bold text-foreground">Upcoming</h2>
                <span className="bg-blue-100 text-blue-700 text-xs font-semibold px-2 py-0.5 rounded-full">{upcoming.length}</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {upcoming.map(s => (
                  <SessionCard key={s.id} session={s} onClick={() => navigate(`/session/${s.id}`)} />
                ))}
              </div>
            </section>
          )}

          {completed.length > 0 && (
            <section>
              <div className="flex items-center gap-2 mb-4">
                <CheckCircle className="w-4 h-4 text-gray-500" />
                <h2 className="font-bold text-foreground">Completed</h2>
                <span className="bg-gray-100 text-gray-600 text-xs font-semibold px-2 py-0.5 rounded-full">{completed.length}</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {completed.map(s => (
                  <SessionCard key={s.id} session={s} onClick={() => navigate(`/session/${s.id}/results`)} />
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </Layout>
  );
}
