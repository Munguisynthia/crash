import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { AuthLayout } from "../components/Layout";
import { api, storeAuth } from "../lib/api";
import { Mail, Lock, Loader2, ArrowRight, Shield } from "lucide-react";

export function SystemAdminLogin() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "setup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    api.checkSysadmin()
      .then(res => setMode(res.exists ? "login" : "setup"))
      .catch(() => setMode("login"))
      .finally(() => setLoading(false));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (mode === "setup" && password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    setSubmitting(true);
    try {
      if (mode === "setup") {
        await api.setupSysadmin(email.trim(), password);
        setMode("login");
        setPassword(""); setConfirmPassword("");
        return;
      }
      const res = await api.sysadminLogin(email.trim(), password);
      storeAuth(res.token, "sysadmin", { email, name: "System Admin" });
      navigate("/system-admin/dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return <AuthLayout><div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-muted-foreground" /></div></AuthLayout>;
  }

  return (
    <AuthLayout>
      <div className="bg-card rounded-2xl shadow-sm border border-border p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
            <Shield className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">{mode === "setup" ? "Create System Admin" : "System Admin"}</h2>
            <p className="text-muted-foreground text-xs">{mode === "setup" ? "One-time setup — create your admin account" : "Platform administration access"}</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full pl-10 pr-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" placeholder="admin@votetrack.app" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} required className="w-full pl-10 pr-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" placeholder="••••••••" />
            </div>
          </div>
          {mode === "setup" && (
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Confirm Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required className="w-full pl-10 pr-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" placeholder="••••••••" />
              </div>
            </div>
          )}
          {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg">{error}</div>}
          <button type="submit" disabled={submitting} className="w-full bg-primary text-primary-foreground py-2.5 px-4 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-60">
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <>{mode === "setup" ? "Create Admin Account" : "Sign In"} <ArrowRight className="w-4 h-4" /></>}
          </button>
        </form>
      </div>
    </AuthLayout>
  );
}
