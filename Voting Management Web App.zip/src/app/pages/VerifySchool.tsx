import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router";
import { api } from "../lib/api";
import { AuthLayout } from "../components/Layout";
import { CheckCircle, XCircle, Loader2, School, Lock, User } from "lucide-react";

export function VerifySchool() {
  const { token } = useParams<{ token: string }>();
  const navigate = useNavigate();
  const [step, setStep] = useState<"loading" | "form" | "success" | "error">("loading");
  const [schoolData, setSchoolData] = useState<any>(null);
  const [adminName, setAdminName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!token) return;
    api.getSchoolToken(token)
      .then(res => {
        setSchoolData(res.school);
        setStep("form");
      })
      .catch(err => {
        setError(err.message);
        setStep("error");
      });
  }, [token]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) { setError("Passwords do not match"); return; }
    if (password.length < 8) { setError("Password must be at least 8 characters"); return; }
    setError("");
    setSubmitting(true);
    try {
      await api.verifySchool(token!, adminName.trim(), password);
      setStep("success");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthLayout>
      <div className="bg-card rounded-2xl shadow-sm border border-border p-8">
        {step === "loading" && (
          <div className="text-center py-8">
            <Loader2 className="w-10 h-10 animate-spin text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Verifying your access link…</p>
          </div>
        )}

        {step === "form" && schoolData && (
          <>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                <School className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-foreground">Set Up School Admin Account</h2>
                <p className="text-muted-foreground text-sm">{schoolData.name}</p>
              </div>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  <span className="flex items-center gap-1.5"><User className="w-3.5 h-3.5 text-muted-foreground" /> Your Full Name *</span>
                </label>
                <input type="text" value={adminName} onChange={e => setAdminName(e.target.value)} required className="w-full px-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" placeholder="School Administrator Name" />
              </div>
              <div className="bg-secondary/50 border border-border rounded-lg px-4 py-3 text-sm text-muted-foreground">
                Account email: <strong className="text-foreground">{schoolData.email}</strong>
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  <span className="flex items-center gap-1.5"><Lock className="w-3.5 h-3.5 text-muted-foreground" /> Password *</span>
                </label>
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={8} className="w-full px-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" placeholder="At least 8 characters" />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">Confirm Password *</label>
                <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required className="w-full px-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring" placeholder="Repeat password" />
              </div>
              {error && <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg">{error}</div>}
              <button type="submit" disabled={submitting} className="w-full bg-primary text-primary-foreground py-2.5 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-60">
                {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Create Admin Account"}
              </button>
            </form>
          </>
        )}

        {step === "success" && (
          <div className="text-center py-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Account Created!</h2>
            <p className="text-muted-foreground text-sm mb-6">Your school admin account has been set up successfully. You can now sign in to manage your school's elections.</p>
            <button onClick={() => navigate("/school-admin/login")} className="bg-primary text-primary-foreground px-6 py-2.5 rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity">
              Go to School Admin Login
            </button>
          </div>
        )}

        {step === "error" && (
          <div className="text-center py-6">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Invalid Link</h2>
            <p className="text-muted-foreground text-sm">{error || "This access link is invalid or has expired."}</p>
          </div>
        )}
      </div>
    </AuthLayout>
  );
}
