import { useEffect, useState } from "react";
import { useParams } from "react-router";
import { api } from "../lib/api";
import { AuthLayout } from "../components/Layout";
import { CheckCircle, XCircle, Loader2, Mic, Image as ImageIcon } from "lucide-react";

export function CandidateVerify() {
  const { token } = useParams<{ token: string }>();
  const [step, setStep] = useState<"loading" | "form" | "success" | "error">("loading");
  const [data, setData] = useState<any>(null);
  const [pitch, setPitch] = useState("");
  const [photo, setPhoto] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!token) return;
    api.getCandidateToken(token)
      .then(res => {
        setData(res);
        setStep("form");
      })
      .catch(err => {
        setError(err.message);
        setStep("error");
      });
  }, [token]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !pitch.trim()) return;
    setSubmitting(true);
    try {
      await api.submitPitch(token, pitch.trim(), photo.trim());
      setStep("success");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthLayout>
      <div className="bg-card rounded-2xl shadow-sm border border-border p-8">
        {step === "loading" && (
          <div className="text-center py-8">
            <Loader2 className="w-10 h-10 animate-spin text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Verifying your candidacy link…</p>
          </div>
        )}

        {step === "form" && data && (
          <>
            <div className="mb-6">
              <span className="inline-block bg-primary/10 text-primary text-xs font-semibold px-2.5 py-1 rounded-full mb-3">
                {data.school?.name}
              </span>
              <h2 className="text-2xl font-bold text-foreground mb-1">Submit Your Election Pitch</h2>
              <p className="text-muted-foreground text-sm">
                Hi <strong>{data.candidate?.name}</strong>, you've been nominated for <strong>{data.session?.title}</strong>. Write your pitch to introduce yourself to voters.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-1.5">
                  <Mic className="w-4 h-4 text-muted-foreground" /> Your Election Pitch *
                </label>
                <textarea
                  value={pitch}
                  onChange={e => setPitch(e.target.value)}
                  required
                  rows={6}
                  maxLength={1000}
                  className="w-full px-4 py-3 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                  placeholder="Tell voters who you are, why you're running, and what you plan to achieve if elected…"
                />
                <p className="text-xs text-muted-foreground mt-1 text-right">{pitch.length}/1000</p>
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-foreground mb-1.5">
                  <ImageIcon className="w-4 h-4 text-muted-foreground" /> Profile Photo URL <span className="text-muted-foreground font-normal">(optional)</span>
                </label>
                <input
                  type="url"
                  value={photo}
                  onChange={e => setPhoto(e.target.value)}
                  className="w-full px-4 py-2.5 bg-input-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="https://example.com/your-photo.jpg"
                />
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg">{error}</div>
              )}

              <button
                type="submit"
                disabled={submitting || !pitch.trim()}
                className="w-full bg-primary text-primary-foreground py-2.5 px-4 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-60"
              >
                {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Submit My Pitch"}
              </button>
            </form>
          </>
        )}

        {step === "success" && (
          <div className="text-center py-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Pitch Submitted!</h2>
            <p className="text-muted-foreground text-sm">Your election pitch has been recorded. Voters will now be able to see your profile when the election opens.</p>
            <p className="text-muted-foreground text-sm mt-3">Good luck with your campaign!</p>
          </div>
        )}

        {step === "error" && (
          <div className="text-center py-6">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Invalid Link</h2>
            <p className="text-muted-foreground text-sm">{error || "This verification link is invalid or has expired. Please contact your school administration."}</p>
          </div>
        )}
      </div>
    </AuthLayout>
  );
}
