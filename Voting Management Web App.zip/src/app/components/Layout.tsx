import { ReactNode } from "react";
import { useNavigate, useLocation } from "react-router";
import { clearAuth, getStoredRole, getStoredUser } from "../lib/api";
import { Vote, LogOut, Users, Calendar, BarChart2, School, Settings, Home, ChevronRight } from "lucide-react";

interface LayoutProps {
  children: ReactNode;
  title?: string;
  breadcrumb?: string;
}

export function Layout({ children, title, breadcrumb }: LayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const role = getStoredRole();
  const user = getStoredUser();

  const handleLogout = async () => {
    clearAuth();
    if (role === "sysadmin") navigate("/system-admin/login");
    else if (role === "school_admin") navigate("/school-admin/login");
    else navigate("/");
  };

  const studentNav = [
    { label: "Dashboard", icon: Home, path: "/dashboard" },
    { label: "Results", icon: BarChart2, path: "/results" },
  ];

  const adminNav = [
    { label: "Dashboard", icon: Home, path: "/school-admin/dashboard" },
    { label: "Sessions", icon: Calendar, path: "/school-admin/sessions" },
    { label: "Students", icon: Users, path: "/school-admin/students" },
    { label: "Candidates", icon: Vote, path: "/school-admin/candidates" },
  ];

  const sysadminNav = [
    { label: "Schools", icon: School, path: "/system-admin/dashboard" },
  ];

  const nav = role === "sysadmin" ? sysadminNav : role === "school_admin" ? adminNav : studentNav;

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className="w-60 bg-primary flex flex-col flex-shrink-0 min-h-screen">
        <div className="px-6 py-8 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
              <Vote className="w-4 h-4 text-white" />
            </div>
            <span className="text-white font-bold text-lg tracking-tight">VoteTrack</span>
          </div>
          {user && (
            <div className="mt-4">
              <p className="text-white/90 font-medium text-sm truncate">{user.name || user.email}</p>
              <p className="text-white/50 text-xs mt-0.5 truncate">
                {role === "sysadmin" ? "System Admin" : role === "school_admin" ? "School Admin" : user.studentId}
              </p>
            </div>
          )}
        </div>
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {nav.map(({ label, icon: Icon, path }) => {
            const active = location.pathname === path || location.pathname.startsWith(path + "/");
            return (
              <button
                key={path}
                onClick={() => navigate(path)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-left ${
                  active ? "bg-white/15 text-white" : "text-white/60 hover:text-white hover:bg-white/8"
                }`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                {label}
              </button>
            );
          })}
        </nav>
        <div className="px-3 py-4 border-t border-white/10">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/60 hover:text-white hover:bg-white/8 transition-colors"
          >
            <LogOut className="w-4 h-4 flex-shrink-0" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col min-w-0">
        {(title || breadcrumb) && (
          <header className="bg-card border-b border-border px-8 py-5">
            {breadcrumb && (
              <p className="text-xs text-muted-foreground flex items-center gap-1 mb-1">
                <span>Home</span>
                <ChevronRight className="w-3 h-3" />
                <span>{breadcrumb}</span>
              </p>
            )}
            {title && <h1 className="text-xl font-bold text-foreground">{title}</h1>}
          </header>
        )}
        <div className="flex-1 p-8">{children}</div>
      </main>
    </div>
  );
}

export function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2.5 mb-3">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
              <Vote className="w-5 h-5 text-white" />
            </div>
            <span className="text-2xl font-bold text-foreground tracking-tight">VoteTrack</span>
          </div>
          <p className="text-muted-foreground text-sm">School Election Management System</p>
        </div>
        {children}
      </div>
    </div>
  );
}
