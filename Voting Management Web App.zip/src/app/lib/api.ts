import { projectId, publicAnonKey } from "/utils/supabase/info";

const BASE = `https://${projectId}.supabase.co/functions/v1/make-server-1c5486f2`;

function getToken(): string | null {
  return localStorage.getItem("vt_token");
}

export function getStoredUser(): any | null {
  const raw = localStorage.getItem("vt_user");
  return raw ? JSON.parse(raw) : null;
}

export function getStoredRole(): string | null {
  return localStorage.getItem("vt_role");
}

export function storeAuth(token: string, role: string, user: any) {
  localStorage.setItem("vt_token", token);
  localStorage.setItem("vt_role", role);
  localStorage.setItem("vt_user", JSON.stringify(user));
}

export function clearAuth() {
  localStorage.removeItem("vt_token");
  localStorage.removeItem("vt_role");
  localStorage.removeItem("vt_user");
}

async function request(method: string, path: string, body?: any, authToken?: string) {
  const token = authToken ?? getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${token ?? publicAnonKey}`,
  };
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

// Auth
export const api = {
  requestOtp: (email: string, studentId: string) =>
    request("POST", "/auth/request-otp", { email, studentId }),
  verifyOtp: (email: string, studentId: string, otp: string) =>
    request("POST", "/auth/verify-otp", { email, studentId, otp }),
  logout: () => request("POST", "/auth/logout"),

  // System admin
  checkSysadmin: () => request("GET", "/sysadmin/check"),
  setupSysadmin: (email: string, password: string) =>
    request("POST", "/sysadmin/setup", { email, password }),
  sysadminLogin: (email: string, password: string) =>
    request("POST", "/sysadmin/login", { email, password }),
  getSchools: () => request("GET", "/sysadmin/schools"),
  createSchool: (data: { name: string; govId: string; email: string; studentPrefix: string }) =>
    request("POST", "/sysadmin/schools", data),

  // School verification
  getSchoolToken: (token: string) =>
    request("GET", `/verify/school/${token}`, undefined, publicAnonKey),
  verifySchool: (token: string, adminName: string, password: string) =>
    request("POST", `/verify/school/${token}`, { adminName, password }, publicAnonKey),

  // School admin auth
  schoolAdminLogin: (email: string, password: string) =>
    request("POST", "/school-admin/login", { email, password }),

  // Students
  getStudents: () => request("GET", "/school-admin/students"),
  createStudent: (data: { name: string; email: string; studentId: string }) =>
    request("POST", "/school-admin/students", data),
  verifyStudent: (token: string) =>
    request("GET", `/verify/student/${token}`, undefined, publicAnonKey),

  // Candidates
  getCandidates: (sessionId?: string) =>
    request("GET", `/school-admin/candidates${sessionId ? `?sessionId=${sessionId}` : ""}`),
  createCandidate: (data: { name: string; email: string; sessionId: string; position?: string }) =>
    request("POST", "/school-admin/candidates", data),
  getCandidateToken: (token: string) =>
    request("GET", `/verify/candidate/${token}`, undefined, publicAnonKey),
  submitPitch: (token: string, pitch: string, photo?: string) =>
    request("POST", `/verify/candidate/${token}`, { pitch, photo }, publicAnonKey),

  // Sessions (admin)
  getAdminSessions: () => request("GET", "/school-admin/sessions"),
  createSession: (data: { title: string; description?: string; startDate: string; endDate: string }) =>
    request("POST", "/school-admin/sessions", data),
  updateSession: (id: string, data: any) =>
    request("PUT", `/school-admin/sessions/${id}`, data),

  // Sessions (student)
  getSessions: () => request("GET", "/student/sessions"),
  getSession: (id: string) => request("GET", `/student/session/${id}`),
  vote: (sessionId: string, candidateId: string) =>
    request("POST", "/student/vote", { sessionId, candidateId }),
  getResults: (sessionId: string) => request("GET", `/student/results/${sessionId}`),
  getAdminResults: (sessionId: string) => request("GET", `/school-admin/results/${sessionId}`),
};
