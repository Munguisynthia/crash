import { BrowserRouter, Routes, Route, Navigate } from "react-router";
import { getStoredRole } from "./lib/api";

import { StudentLogin } from "./pages/StudentLogin";
import { StudentDashboard } from "./pages/StudentDashboard";
import { SessionDetail } from "./pages/SessionDetail";
import { VotePage } from "./pages/VotePage";
import { ResultsPage } from "./pages/ResultsPage";
import { VerifyStudent } from "./pages/VerifyStudent";
import { CandidateVerify } from "./pages/CandidateVerify";

import { SchoolAdminLogin } from "./pages/SchoolAdminLogin";
import { SchoolAdminDashboard } from "./pages/SchoolAdminDashboard";
import { ManageSessions } from "./pages/ManageSessions";
import { ManageStudents } from "./pages/ManageStudents";
import { ManageCandidates } from "./pages/ManageCandidates";
import { VerifySchool } from "./pages/VerifySchool";

import { SystemAdminLogin } from "./pages/SystemAdminLogin";
import { SystemAdminDashboard } from "./pages/SystemAdminDashboard";

function RequireAuth({ children, role }: { children: React.ReactNode; role: string }) {
  const storedRole = getStoredRole();
  if (!storedRole) return <Navigate to="/" replace />;
  if (storedRole !== role) {
    if (storedRole === "student") return <Navigate to="/dashboard" replace />;
    if (storedRole === "school_admin") return <Navigate to="/school-admin/dashboard" replace />;
    if (storedRole === "sysadmin") return <Navigate to="/system-admin/dashboard" replace />;
    return <Navigate to="/" replace />;
  }
  return <>{children}</>;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Student auth & public */}
        <Route path="/" element={<StudentLogin />} />
        <Route path="/verify/student/:token" element={<VerifyStudent />} />
        <Route path="/candidate/verify/:token" element={<CandidateVerify />} />
        <Route path="/verify/school/:token" element={<VerifySchool />} />

        {/* Student protected */}
        <Route path="/dashboard" element={<RequireAuth role="student"><StudentDashboard /></RequireAuth>} />
        <Route path="/session/:id" element={<RequireAuth role="student"><SessionDetail /></RequireAuth>} />
        <Route path="/session/:id/vote/:candidateId" element={<RequireAuth role="student"><VotePage /></RequireAuth>} />
        <Route path="/session/:id/results" element={<ResultsPage />} />

        {/* School admin */}
        <Route path="/school-admin/login" element={<SchoolAdminLogin />} />
        <Route path="/school-admin/dashboard" element={<RequireAuth role="school_admin"><SchoolAdminDashboard /></RequireAuth>} />
        <Route path="/school-admin/sessions" element={<RequireAuth role="school_admin"><ManageSessions /></RequireAuth>} />
        <Route path="/school-admin/students" element={<RequireAuth role="school_admin"><ManageStudents /></RequireAuth>} />
        <Route path="/school-admin/candidates" element={<RequireAuth role="school_admin"><ManageCandidates /></RequireAuth>} />

        {/* System admin */}
        <Route path="/system-admin/login" element={<SystemAdminLogin />} />
        <Route path="/system-admin/dashboard" element={<RequireAuth role="sysadmin"><SystemAdminDashboard /></RequireAuth>} />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
