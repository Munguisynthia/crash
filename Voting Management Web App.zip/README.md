
  # Voting Management Web App

  This is a code bundle for Voting Management Web App. The original project is available at https://www.figma.com/design/t3xxoQTwap9aurRsyBYn0I/Voting-Management-Web-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  